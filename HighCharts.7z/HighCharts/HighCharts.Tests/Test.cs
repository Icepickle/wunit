﻿using NUnit.Framework;
using System;

namespace HighCharts.Tests
{
	[TestFixture]
	public class Test
	{
		[Test]
		public void TestCase()
		{
		}
	}
}
