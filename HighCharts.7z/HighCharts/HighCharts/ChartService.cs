﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace HighCharts {
	/// <summary>
	/// Simple data service
	/// </summary>
	public class DataService<T> {
		private readonly ICollection<T> _store;

		public DataService(ICollection<T> store) {
			if (store == null) {
				throw new ArgumentNullException(nameof(store));
			}
			_store = store;
		}
		
		public IEnumerable<T> GetAll() {
			return _store;
		}

		public IEnumerable<T> Find(Predicate<T> predicate) {
			return _store.Where( item => predicate(item) );
		}

		public void Add(T item) {
			_store.Add(item);
		}

		public void Delete(T item) {
			_store.Remove(item);
		}

		/// <summary>
		/// Update an item in the store, assuming the item is Immutable, and the Equality comparer is made for a single property
		/// (ie: for FruitItem, the equals method for Name is overwritten)
		/// </summary>
		/// <param name="item">Item</param>
		public void Update(T item) {
			// throws item out based on the name
			_store.Remove(item);
			// and adds it back in
			_store.Add(item);
		}
	}

	public class FruitItem {
		// name is used as primary key
		public string Name { get; }
		public int Failed { get; }
		public int Succeeded { get; }
		public int Service { get; }

		public FruitItem(string name, int failed, int succeeded, int service) {
			Name = name;
			Failed = failed;
			Succeeded = succeeded;
			Service = service;
		}

		public override bool Equals(object obj)
		{
			return Name.Equals((obj as FruitItem)?.Name);
		}

		public override int GetHashCode()
		{
			return (Name ?? "42").GetHashCode();
		}
	}
}
