﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using HighCharts;

public partial class getcharts : System.Web.UI.Page
{
	private static int TickCounter = 0;
	private readonly static DataService<FruitItem> _fruitService;
	private static string[] fruitNames = new string[] { "Peer", "Banana", "Kiwi", "Orange", "Blueberry" };
	private static Random randomGenerator = new Random();

	static getcharts() {
		_fruitService = new DataService<FruitItem>(new HashSet<FruitItem>());
		_fruitService.Add(new FruitItem("Strawberry", 100, 200, 400));
		_fruitService.Add(new FruitItem("Apples", 200, 100, 400));
		_fruitService.Add(new FruitItem("Pineapple", 300, 200, 400));
		_fruitService.Add(new FruitItem("Mango", 100, 200, 400));
	}

	[WebMethod]
	public static FruitItem[] calctranscs()
	{
		return _fruitService.GetAll().ToArray();
	}

	[WebMethod]
	public static int Counter()
	{
		if (++TickCounter % 5 == 0)
		{
			// will try to add a fruit into the fruitservice
			// if the fruit was already added by name, nothing will change
			_fruitService.Add(new FruitItem(fruitNames[randomGenerator.Next(fruitNames.Length)], (randomGenerator.Next(5) + 1) * 100, (randomGenerator.Next(5) + 1) * 100, (randomGenerator.Next(5) + 1) * 100 ));
		}
		return ++TickCounter;
	}
}